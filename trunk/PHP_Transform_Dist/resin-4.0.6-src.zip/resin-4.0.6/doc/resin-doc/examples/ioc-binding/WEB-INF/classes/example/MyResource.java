package example;

public interface MyResource {
  public String getMessage();
}