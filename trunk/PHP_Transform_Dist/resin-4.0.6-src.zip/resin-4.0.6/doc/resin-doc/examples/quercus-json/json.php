<?php
   $array = array("a"=>"Caucho", "b"=>"Resin", "c"=>"Quercus");
   $json = json_encode($array);
   echo $json;
 ?>