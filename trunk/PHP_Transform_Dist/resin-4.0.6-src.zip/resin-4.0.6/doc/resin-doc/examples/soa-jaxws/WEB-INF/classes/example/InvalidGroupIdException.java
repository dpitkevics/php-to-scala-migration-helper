package example;

public class InvalidGroupIdException extends Exception
{
  public InvalidGroupIdException()
  {
    super();
  }

  public InvalidGroupIdException(String message)
  {
    super(message);
  }
}
