package java.sql;

public interface NBlob {
}
