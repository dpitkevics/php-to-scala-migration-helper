package java.sql;

public interface SQLXML {
}
