package java.sql;

public interface RowId {
}
