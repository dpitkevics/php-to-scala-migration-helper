package com.opensymphony.xwork2;

import java.util.*;

public class ObjectFactory {
  public Object buildBean(Class clazz, Map extraContext)
    throws Exception
  {
    throw new UnsupportedOperationException(getClass().getName());
  }
}
